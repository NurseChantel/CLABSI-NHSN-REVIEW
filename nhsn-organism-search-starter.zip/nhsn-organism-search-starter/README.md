# NHSN Organism Search Starter

A taxonomy-aware starter database and search module for a CLABSI/BSI decision-support website.

## What it does

- Lets the user paste the organism exactly as shown in a culture report.
- Ignores capitalization, parentheses, punctuation, and common lab flags.
- Searches current names, former taxonomy names, abbreviations, and aliases.
- Returns ranked matches.
- Supports an NHSN classification, MBI-eligibility field, and manual-review flag.
- Keeps organism data separate from application logic.

## Important

This repository contains only a small starter dataset. It is **not** a complete or production-validated NHSN organism database. Before using it for surveillance decisions, validate every classification against the current NHSN Patient Safety Component Manual and official NHSN organism resources.

## Files

```text
data/
  organisms.json
  organisms.schema.json
src/
  organism-search.js
index.html
README.md
```

## Run locally

Because the JavaScript loads JSON with `fetch()`, open it through a local web server rather than double-clicking `index.html`.

### VS Code

Install the Live Server extension, right-click `index.html`, and choose **Open with Live Server**.

### Python

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Add an organism

Add a new object to `data/organisms.json`:

```json
{
  "id": "unique-lowercase-id",
  "canonicalName": "Current accepted name",
  "displayName": "Name shown to the user",
  "aliases": [
    "Former taxonomy name",
    "Common laboratory wording",
    "Abbreviation"
  ],
  "searchTerms": [
    "Other useful searchable wording"
  ],
  "taxonomy": {
    "currentGenus": "Genus",
    "formerGenus": ["OldGenus"],
    "species": "species"
  },
  "nhsn": {
    "classification": "common_commensal",
    "mbiEligible": false,
    "reviewRequired": false,
    "notes": "Source or review note"
  }
}
```

## Recommended next production steps

1. Add source citations and a `sourceVersion` to every NHSN classification.
2. Add automated JSON-schema validation in GitHub Actions.
3. Add tests for real culture-report strings.
4. Keep unresolved or genus-only results marked `reviewRequired: true`.
5. Never silently classify a low-confidence match.
